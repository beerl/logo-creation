document.addEventListener('DOMContentLoaded', function() {
    const logoForm = document.getElementById('logo-form');
    const uploadBtn = document.getElementById('upload-btn');
    const previewImage = document.getElementById('preview-image');
    const noPreview = document.getElementById('no-preview');
    const loading = document.getElementById('loading');
    const previewDownloadBtn = document.getElementById('preview-download-btn');
    const downloadContainer = document.getElementById('download-container');
    const errorMessage = document.getElementById('error-message');
    const simpleGuides = document.getElementById('simple-guides');
    
    // Nouveaux éléments pour les contrôles
    const adjustmentControls = document.getElementById('adjustment-controls');
    const horizontalPosition = document.getElementById('horizontal-position');
    const verticalPosition = document.getElementById('vertical-position');
    const scaleFactor = document.getElementById('scale-factor');
    const horizontalValue = document.getElementById('horizontal-value');
    const verticalValue = document.getElementById('vertical-value');
    const scaleValue = document.getElementById('scale-value');
    const processButtonContainer = document.getElementById('process-button-container');
    
    // Nouveaux éléments pour le choix image/texte
    const typeImage = document.getElementById('type-image');
    const typeText = document.getElementById('type-text');
    const imageSection = document.getElementById('image-section');
    const textSection = document.getElementById('text-section');
    const logoTextInput = document.getElementById('logo-text');
    
    let currentFilename = null; // Stocker le nom du fichier traité
    let currentType = 'image'; // Type actuel (image ou text)
    
    // Gestionnaire pour le champ texte avec mise à jour automatique
    logoTextInput.addEventListener('input', function() {
        if (currentType === 'text') {
            debounceUpdate();
        }
    });
    
    // Gestionnaires pour les sliders avec mise à jour automatique
    horizontalPosition.addEventListener('input', function() {
        horizontalValue.textContent = this.value;
        if (currentFilename) {
            debounceUpdate();
        }
    });
    
    verticalPosition.addEventListener('input', function() {
        verticalValue.textContent = this.value;
        if (currentFilename) {
            debounceUpdate();
        }
    });
    
    scaleFactor.addEventListener('input', function() {
        scaleValue.textContent = Math.round(this.value * 100);
        if (currentFilename) {
            debounceUpdate();
        }
    });
    
    // Gestionnaire pour les radio buttons
    typeImage.addEventListener('change', function() {
        if (this.checked) {
            currentType = 'image';
            imageSection.classList.remove('d-none');
            textSection.classList.add('d-none');
            processButtonContainer.classList.remove('d-none');
            // Réinitialiser le champ texte
            logoTextInput.value = '';
            // Masquer les contrôles si pas d'image
            if (!currentFilename) {
                adjustmentControls.classList.add('d-none');
                simpleGuides.classList.add('d-none');
            }
        }
    });
    
    typeText.addEventListener('change', function() {
        if (this.checked) {
            currentType = 'text';
            textSection.classList.remove('d-none');
            imageSection.classList.add('d-none');
            processButtonContainer.classList.add('d-none');
            // Si il y a déjà du texte, le traiter
            if (logoTextInput.value.trim()) {
                processText(logoTextInput.value.trim());
            }
        }
    });
    
    // Fonction de debounce pour éviter trop de requêtes
    let updateTimeout;
    function debounceUpdate() {
        clearTimeout(updateTimeout);
        updateTimeout = setTimeout(() => {
            if (currentType === 'text') {
                const text = logoTextInput.value.trim();
                if (text) {
                    showLoading();
                    processText(text);
                }
            } else {
                updatePreview();
            }
        }, 300); // Attendre 300ms après le dernier changement
    }
    
    // Gestionnaire pour le formulaire de téléchargement
    logoForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (currentType === 'image') {
            const fileInput = document.getElementById('logo');
            const file = fileInput.files[0];
            
            if (!file) {
                showError('Veuillez sélectionner un fichier');
                return;
            }
            
            // Vérifier le type de fichier
            const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/svg+xml'];
            if (!allowedTypes.includes(file.type)) {
                showError('Format de fichier non supporté. Veuillez utiliser PNG, JPG, JPEG, GIF ou SVG.');
                return;
            }
            
            showLoading();
            processImage(file);
        } else {
            // Type texte
            const text = logoTextInput.value.trim();
            
            if (!text) {
                showError('Veuillez entrer un texte');
                return;
            }
            
            showLoading();
            processText(text);
        }
    });
    
    // Fonction pour traiter l'image
    function processImage(file) {
        const formData = new FormData();
        formData.append('logo', file);
        formData.append('horizontal_offset', horizontalPosition.value);
        formData.append('vertical_offset', verticalPosition.value);
        formData.append('scale_factor', scaleFactor.value);
        formData.append('type', 'image');
        
        fetch('/process_logo', {
            method: 'POST',
            body: formData
        })
        .then(handleResponse)
        .then(handleSuccess)
        .catch(handleError);
    }
    
    // Fonction pour traiter le texte
    function processText(text) {
        const formData = new FormData();
        formData.append('logo-text', text);
        formData.append('horizontal_offset', horizontalPosition.value);
        formData.append('vertical_offset', verticalPosition.value);
        formData.append('scale_factor', parseFloat(scaleFactor.value));
        formData.append('type', 'text');
        
        console.log('Sending text with scale_factor:', parseFloat(scaleFactor.value));
        
        fetch('/process_logo', {
            method: 'POST',
            body: formData
        })
        .then(handleResponse)
        .then(handleSuccess)
        .catch(handleError);
    }
    
    // Fonction pour gérer la réponse
    function handleResponse(response) {
        if (!response.ok) {
            return response.json().then(data => {
                throw new Error(data.error || 'Une erreur est survenue lors du traitement');
            });
        }
        return response.json();
    }
    
    // Fonction pour gérer le succès
    function handleSuccess(data) {
        if (data.success) {
            currentFilename = data.filename;
            
            // Afficher les contrôles d'ajustement
            adjustmentControls.classList.remove('d-none');
            
            // Mettre à jour le bouton de téléchargement
            previewDownloadBtn.href = `/processed/${data.filename}?download=true`;
            downloadContainer.classList.remove('d-none');
            
            // Afficher l'image
            const timestamp = new Date().getTime(); // Cache-busting
            previewImage.src = `/processed/${data.filename}?t=${timestamp}`;
            previewImage.classList.remove('d-none');
            previewImage.classList.add('fadeIn');
            
            // Attendre que l'image soit chargée pour ajuster les guides
            previewImage.onload = function() {
                adjustGuidesToImage();
                simpleGuides.classList.remove('d-none');
            };
            
            noPreview.classList.add('d-none');
            loading.classList.add('d-none');
            
            // Hide any previous errors
            errorMessage.classList.add('d-none');
        } else {
            showError(data.error || 'Une erreur est survenue');
        }
    }
    
    // Fonction pour gérer les erreurs
    function handleError(error) {
        showError(error.message || 'Une erreur est survenue lors du traitement');
    }
    
    // Fonction pour mettre à jour la prévisualisation avec les nouveaux paramètres
    function updatePreview() {
        if (currentType === 'image') {
            const fileInput = document.getElementById('logo');
            const file = fileInput.files[0];
            if (!file) return;
            showLoading();
            processImage(file);
        } else {
            const text = logoTextInput.value.trim();
            if (!text) return;
            showLoading();
            processText(text);
        }
    }
    
    // Fonction pour afficher les erreurs
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.remove('d-none');
        loading.classList.add('d-none');
        simpleGuides.classList.add('d-none');
    }
    
    // Fonction pour afficher l'état de chargement
    function showLoading() {
        loading.classList.remove('d-none');
        errorMessage.classList.add('d-none');
        previewImage.classList.add('d-none');
        noPreview.classList.add('d-none');
        downloadContainer.classList.add('d-none');
        simpleGuides.classList.add('d-none');
    }
    
    // Fonction pour ajuster les guides aux dimensions de l'image
    function adjustGuidesToImage() {
        const imgRect = previewImage.getBoundingClientRect();
        const containerRect = document.getElementById('preview-container').getBoundingClientRect();
        
        // Positionner le conteneur des guides exactement sur l'image
        simpleGuides.style.width = imgRect.width + 'px';
        simpleGuides.style.height = imgRect.height + 'px';
        simpleGuides.style.top = '50%';
        simpleGuides.style.left = '50%';
        simpleGuides.style.transform = 'translate(-50%, -50%)';
    }
});
